 * [Lighttp](https://www.lighttpd.net/) 
 * [Raspberry Pi](https://www.raspberrypi.org/)
 * [Twitter-Bootstrap](http://getbootstrap.com/)
 * [Font Awesome](https://fortawesome.github.io/Font-Awesome/)
